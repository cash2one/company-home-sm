<?php
global $em_educations;
$em_educations = array();
$em_educations['1'] = '初中以上';
$em_educations['2'] = '高中/中专';
$em_educations['3'] = '大学专科';
$em_educations['4'] = '大学本科';
$em_educations['5'] = '硕士';
$em_educations['6'] = '博士以上';
?>